# FormFit Lite

A lightweight, offline-first Android form-preparation toolkit.

## Included in this starter
- Native Kotlin Android project (no third-party runtime libraries)
- Home screen with the 20 planned tool entries
- Working age calculator
- Working percentage calculator
- GitHub Actions workflow to build debug and unsigned release APK artifacts
- No account, analytics SDK, network permission, or automatic document upload

## Build APK on GitHub
1. Upload this project to the root of your GitHub repository.
2. Open the **Actions** tab.
3. Select **FormFit Lite Android APK**.
4. Run the workflow, or make a new commit to trigger it.
5. Download the APK from the workflow run's **Artifacts** section.

## Project status
This is a buildable starter foundation, not the completed 20-feature product. Tool cards marked "Planned feature" are roadmap items and need implementation. The age and percentage calculators are functional.

## Build configuration
- JDK 17
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Gradle 8.9
- Android SDK 35
- Minimum Android API 23

The GitHub workflow installs Gradle directly, so a Gradle wrapper is not required for the hosted build.

## Privacy
The starter app does not request broad storage permissions and does not upload documents. Future document features should use Android's system document picker and keep processing on-device by default.
