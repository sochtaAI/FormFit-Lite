package com.formfitlite

import android.app.Activity
import android.app.DatePickerDialog
import android.os.Bundle
import android.graphics.Color
import android.view.View
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {
    private val ink = Color.rgb(24, 39, 35)
    private val green = Color.rgb(23, 107, 91)
    private val muted = Color.rgb(103, 119, 113)
    private val page = Color.rgb(244, 247, 246)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = page
        window.navigationBarColor = page
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        showHome()
    }

    private fun showHome() {
        val scroll = ScrollView(this).apply { setBackgroundColor(page) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        scroll.addView(root)

        root.addView(label("FORMFIT LITE", 13, green, true))
        root.addView(label("Your form-ready toolkit", 27, ink, true))
        root.addView(label("Private • Offline-first • Lightweight", 14, muted, false))
        root.addView(space(18))
        root.addView(infoCard("Welcome", "A simple offline-first toolkit. Your documents stay on your device. Choose a tool to get started."))
        root.addView(space(18))

        section(root, "DOCUMENT TOOLS")
        tool(root, "Photo Compressor", "Select an image and prepare a smaller copy", "Planned feature")
        tool(root, "Signature Studio", "Prepare a clean signature image", "Planned feature")
        tool(root, "Background Editor", "Edit photo backgrounds", "Planned feature")
        tool(root, "Passport Photo", "Prepare passport-size photos", "Planned feature")
        tool(root, "Batch Resize", "Resize multiple images", "Planned feature")
        tool(root, "PDF Merge / Split", "Combine or split PDF files", "Planned feature")
        tool(root, "PDF Compressor", "Reduce PDF file size", "Planned feature")
        tool(root, "Document Scanner", "Scan paper documents", "Planned feature")
        tool(root, "OCR Hindi + English", "Extract text from images", "Planned feature")
        tool(root, "Image to PDF", "Convert images into PDF", "Planned feature")

        section(root, "FORM ASSISTANT")
        tool(root, "Form Readiness Checker", "Review common application requirements", "Planned feature")
        tool(root, "Document Checklist", "Track documents you need", "Planned feature")
        tool(root, "Exam Presets", "Save exam-specific document lists", "Planned feature")
        tool(root, "Application Deadline Tracker", "Track important dates", "Planned feature")
        tool(root, "Form Filling Companion", "Keep application notes locally", "Planned feature")
        tool(root, "Offline Document Vault", "Organize files on this device", "Planned feature")
        tool(root, "Duplicate Finder", "Find duplicate local files", "Planned feature")
        tool(root, "Smart File Organizer", "Organize selected documents", "Planned feature")
        tool(root, "QR Scanner", "Scan QR codes", "Planned feature")

        section(root, "CALCULATORS")
        tool(root, "Age Calculator", "Calculate age from date of birth", "Tap to use") {
            showAgeCalculator()
        }
        tool(root, "Percentage Calculator", "Calculate percentage from obtained and total marks", "Tap to use") {
            showPercentageCalculator()
        }

        root.addView(space(14))
        root.addView(label("FormFit Lite • Version 1.0.0", 12, muted, false))
        setContentView(scroll)
    }

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(space(18))
        parent.addView(label(title, 12, green, true))
        parent.addView(space(8))
    }

    private fun tool(parent: LinearLayout, title: String, subtitle: String, status: String, action: (() -> Unit)? = null) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(13), dp(15), dp(13))
            setBackgroundColor(Color.WHITE)
            if (action != null) setOnClickListener { action() }
        }
        card.addView(label(title, 16, ink, true))
        card.addView(label(subtitle, 13, muted, false).apply {
            setPadding(0, dp(4), 0, dp(3))
        })
        card.addView(label(status, 11, if (action == null) muted else green, true))
        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        parent.addView(card, params)
    }

    private fun infoCard(title: String, body: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundColor(Color.WHITE)
        }
        box.addView(label(title, 16, ink, true))
        box.addView(label(body, 14, muted, false).apply { setPadding(0, dp(5), 0, 0) })
        return box
    }

    private fun showAgeCalculator() {
        val c = Calendar.getInstance()
        DatePickerDialog(this, { _, year, month, day ->
            val dob = Calendar.getInstance().apply { set(year, month, day) }
            val today = Calendar.getInstance()
            if (dob.after(today)) {
                message("Date of birth cannot be in the future.")
                return@DatePickerDialog
            }
            var years = today.get(Calendar.YEAR) - year
            var months = today.get(Calendar.MONTH) - month
            var days = today.get(Calendar.DAY_OF_MONTH) - day
            if (days < 0) {
                months--
                val previousMonth = (today.clone() as Calendar).apply { add(Calendar.MONTH, -1) }
                days += previousMonth.getActualMaximum(Calendar.DAY_OF_MONTH)
            }
            if (months < 0) {
                years--
                months += 12
            }
            message("Your age is $years years, $months months and $days days.")
        }, c.get(Calendar.YEAR) - 18, c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun showPercentageCalculator() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(8))
        }
        val obtained = EditText(this).apply {
            hint = "Obtained marks"
            inputType = 8194
        }
        val total = EditText(this).apply {
            hint = "Total marks"
            inputType = 8194
        }
        val result = TextView(this).apply { textSize = 16f; setTextColor(ink) }
        layout.addView(obtained)
        layout.addView(total)
        val calculate = Button(this).apply {
            text = "Calculate"
            setOnClickListener {
                val a = obtained.text.toString().toDoubleOrNull()
                val b = total.text.toString().toDoubleOrNull()
                if (a == null || b == null || b <= 0 || a < 0 || a > b) {
                    result.text = "Enter valid marks (obtained must be between 0 and total)."
                } else {
                    result.text = "Percentage: %.2f%%".format(a / b * 100.0)
                }
            }
        }
        layout.addView(calculate)
        layout.addView(result)
        AlertDialogBuilder.show(this, "Percentage Calculator", layout)
    }

    private fun message(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    }

    private fun label(value: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}

private object AlertDialogBuilder {
    fun show(activity: Activity, title: String, view: View) {
        android.app.AlertDialog.Builder(activity)
            .setTitle(title)
            .setView(view)
            .setPositiveButton("Close", null)
            .show()
    }
}
