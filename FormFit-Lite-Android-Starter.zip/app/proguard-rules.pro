# FormFit Lite shrinker rules.
